# Therapist Churn Indicators — Reference Guide

## Early Warning Signals

These patterns, when observed in simulated system data, indicate increasing churn risk.

### Behavioral Indicators (Platform Analytics)

| Signal | Description | Risk Weight |
|--------|-------------|-------------|
| Session volume decline >20% | Month-over-month drop in completed sessions | High |
| Cancellation rate spike | Jump from baseline by >10 percentage points | High |
| Login frequency drop | Less than 50% of prior 3-month average | Medium |
| Feature disengagement | Stopped using features they previously used regularly | Medium |
| Off-peak scheduling shift | Moving sessions to less desirable times | Low-Medium |
| Profile not updated | Stale profile when previously active updater | Low |

### Operational Indicators (Jira / Support)

| Signal | Description | Risk Weight |
|--------|-------------|-------------|
| Unresolved tickets >14 days | Support tickets aging without response | High |
| Billing disputes | Any active billing or payment disagreement | High |
| Multiple tickets in short window | 3+ tickets in 30 days suggests systemic frustration | Medium |
| Feature requests declined | Therapist asked for something and was told no | Medium |
| Bug reports on core workflow | Issues affecting their daily work | Medium |

### Relationship Indicators (Salesforce / Comms)

| Signal | Description | Risk Weight |
|--------|-------------|-------------|
| No contact >60 days | No meaningful interaction with account team | High |
| NPS decline | Score dropped by 3+ points between surveys | High |
| Negative NPS comment | Explicit dissatisfaction in survey response | High |
| Missed account review | Scheduled review didn't happen | Medium |
| Unresponsive to outreach | Didn't reply to last 2+ contact attempts | Medium |

### Financial Indicators

| Signal | Description | Risk Weight |
|--------|-------------|-------------|
| Revenue decline >30% | Significant drop in platform-generated revenue | High |
| Late payments (new pattern) | Previously on-time, now delayed | Medium |
| Contract renewal approaching | Within 60 days of renewal without discussion | Medium |
| Pricing complaints | Expressed concern about fees/commission rates | Medium |

## Churn Archetypes

When generating simulated data and root causes, these archetypes help create realistic scenarios:

### The Frustrated Operator
- Core workflow is broken (bugs, UX issues)
- Files tickets, initially patient, patience wearing thin
- Sessions decline as they route patients elsewhere
- Key signal: Jira tickets + declining sessions

### The Neglected Partner
- Was once a top performer, hasn't heard from the team
- No proactive outreach, feels like a number
- Gradual disengagement, not a cliff
- Key signal: Communication gap + slow engagement decline

### The Outgrowing Practitioner
- Practice is evolving, platform isn't keeping up
- Feature requests go unfulfilled
- Looking at alternatives that serve their new model
- Key signal: Feature requests + new competitor activity

### The Burned Out
- Personal or professional burnout affecting everything
- Drop is across all platforms, not just OurRitual
- Harder to intervene — it's not about us
- Key signal: Across-the-board decline + reduced responsiveness

### The Price Sensitive
- External financial pressure or internal cost review
- Comparing platform costs vs alternatives
- May respond to adjusted terms
- Key signal: Billing inquiries + pricing questions + revenue awareness
