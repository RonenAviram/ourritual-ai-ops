# Good Assessment Example

## What makes this good:
- Specific evidence cited for every score
- Root causes are distinct and actionable
- Key insight is one clear sentence
- Confidence honestly reflects data quality

```json
{
  "overall_score": 74,
  "risk_level": "high",
  "churn_window": "4-6 weeks without intervention",
  "dimensions": {
    "volume_trajectory": { "score": 82, "note": "62% decline over 8 weeks, accelerating — dropped 8 sessions in last 2 weeks alone" },
    "engagement_signals": { "score": 68, "note": "Login frequency halved but still using core features when active" },
    "unresolved_friction": { "score": 78, "note": "SR-4721 billing dispute open 18 days, no response from support in 9 days" },
    "financial_indicators": { "score": 55, "note": "Revenue declining proportionally to sessions, but payments current" },
    "relationship_health": { "score": 81, "note": "No meaningful contact in 6 weeks, last NPS was 6 with negative comment" }
  },
  "root_causes": [
    {
      "rank": 1,
      "cause": "Unresolved billing dispute creating frustration and eroding trust",
      "likelihood": "high",
      "evidence": ["SR-4721 open 18 days", "NPS comment mentioned billing", "Support response gap of 9 days"],
      "mechanism": "Unresolved financial friction signals the platform doesn't value the therapist's business, making alternatives more attractive"
    },
    {
      "rank": 2,
      "cause": "Loss of momentum and habit due to scheduling changes",
      "likelihood": "medium",
      "evidence": ["Cancellation rate up from 5% to 22%", "Session decline started before billing ticket"],
      "mechanism": "Patient cancellations reduce the therapist's income from the platform, lowering switching costs"
    },
    {
      "rank": 3,
      "cause": "Platform fatigue — feature needs unmet",
      "likelihood": "medium",
      "evidence": ["FR-1205 group session feature request", "Declining feature usage"],
      "mechanism": "Therapist's practice is evolving but the platform isn't keeping up, creating friction with growth goals"
    }
  ],
  "key_insight": "The billing dispute is the trigger, but the underlying issue is that the therapist feels unsupported — fixing the ticket fast is necessary but not sufficient.",
  "confidence": "medium",
  "confidence_note": "No direct therapist communication data — actual sentiment is inferred from behavioral signals"
}
```
