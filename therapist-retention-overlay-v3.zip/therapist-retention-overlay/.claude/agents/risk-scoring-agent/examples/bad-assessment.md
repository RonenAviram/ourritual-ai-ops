# Bad Assessment Example

## What makes this bad:
- Vague notes with no specific data citations
- Root causes overlap and aren't actionable
- Key insight is generic
- Score doesn't match the evidence

```json
{
  "overall_score": 50,
  "risk_level": "medium",
  "churn_window": "unclear",
  "dimensions": {
    "volume_trajectory": { "score": 50, "note": "Sessions have declined" },
    "engagement_signals": { "score": 50, "note": "Less engaged than before" },
    "unresolved_friction": { "score": 50, "note": "There are some open tickets" },
    "financial_indicators": { "score": 50, "note": "Revenue is lower" },
    "relationship_health": { "score": 50, "note": "Haven't talked in a while" }
  },
  "root_causes": [
    {
      "rank": 1,
      "cause": "Therapist is unhappy",
      "likelihood": "high",
      "evidence": ["They're doing fewer sessions"],
      "mechanism": "Unhappy therapists leave"
    }
  ],
  "key_insight": "We should talk to the therapist to understand what's going on.",
  "confidence": "low",
  "confidence_note": "Not enough information"
}
```

## Why this fails:
- All dimensions scored identically at 50 — no actual analysis
- Notes are tautological ("sessions declined" → we already know that)
- Single root cause is circular ("unhappy because fewer sessions")
- Key insight is what anyone would say without data
- Confidence is low but doesn't explain what specific data is missing
