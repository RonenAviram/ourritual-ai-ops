# Therapist Retention Overlay — Sub-Agent Standard

## Key Principle: Agents Have Prompts Only

Agents contain the prompt templates sent TO the sub-agent.
Skills contain instructions for WHEN and HOW to spawn the agent.

## Standard Agent Structure

```
{agent-name}/
├── AGENT-PROMPT.md       # Primary prompt template (REQUIRED)
├── references/           # Supporting documentation
├── templates/            # Response format schemas (JSON)
└── examples/             # Calibration examples
    ├── good-*.md         # Correct output examples
    └── bad-*.md          # Anti-patterns
```

## Current Sub-Agents

| Agent | Purpose | Spawned By |
|-------|---------|------------|
| **risk-scoring-agent** | Independent risk assessment | Phase 1 (risk-assessment skill) |
| **debrief-analysis-agent** | Conversation outcome analysis | Phase 3 (conversation-debrief skill) |

## Spawning Pattern

Sub-agents receive NO conversation context. They evaluate inputs in isolation.

Replace all `{{VARIABLE}}` placeholders before spawning:
1. Extract from conversation — user inputs, stated facts
2. Read from state — case data, simulated system outputs
3. Pass verbatim — don't summarize or paraphrase
