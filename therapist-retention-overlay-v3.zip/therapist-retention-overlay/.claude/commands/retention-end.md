# /retention-end

Close the current retention case with a final summary.

## Flow

1. Generate final case summary with all phases
2. Show outcome assessment
3. Archive the case
4. Ask for feedback on the process

## Final Summary Includes

- Full timeline of the intervention
- Key metrics: risk score progression, session trend, revenue impact
- All commitments and their status
- Lessons learned
- Recommendation: case resolved / needs escalation / schedule re-check

## Feedback Request

```
Before we close this case, I'd like your feedback:

1. How useful was this process? (1-5)
2. What worked well?
3. What could be improved?

This helps improve the methodology for next time.
```
