# /retention-status

Show the current state of the active retention case.

## Display

```
╭──────────────────────────────────────────────────────────────╮
│  📊 Retention Case Status                                     │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  Case: [ID]                                                  │
│  Therapist: [Name] · [Specialty]                             │
│  Current Phase: [N] — [Name]                                 │
│  Risk Level: [Score] — [Level]                               │
│                                                              │
│  Phase Progress:                                             │
│  [✅/🔄/⬜] Phase 0: Intelligence Gathering                  │
│  [✅/🔄/⬜] Phase 1: Risk Assessment                         │
│  [✅/🔄/⬜] Phase 2: Intervention Plan                       │
│  [✅/🔄/⬜] Phase 3: Conversation Debrief                    │
│  [✅/🔄/⬜] Phase 4: Follow-Up & Feedback Loop               │
│                                                              │
│  Open Commitments: [count]                                   │
│  Next Action: [what needs to happen next]                    │
│                                                              │
╰──────────────────────────────────────────────────────────────╯
```
