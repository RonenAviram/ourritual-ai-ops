# /retention-start

Begin a new therapist retention case.

## Suggested Starting Prompt

Tell the user to write something like:

> I have a feeling that [therapist name] isn't really with us anymore. I'm not sure what exactly is going on, but something has changed. Can you help me look into it?

They can also be more specific if they want — add session numbers, suspected causes, anything. But a name and a feeling is enough to start.

## Flow

1. If the user already described a therapist concern → go directly to intelligence-gathering skill
2. If the user just typed `/retention-start` without context → prompt them:

```
Tell me about the therapist you're concerned about.

You can start with just a name and a feeling — 
"I have a feeling that [Name] isn't really with us anymore"

Or share more if you have it — session numbers, things you've noticed, 
anything that's making you uneasy.
```

3. Once input received → parse with intelligence-gathering skill
4. "Find" the therapist, pull data, present brief
5. Wait for approval to begin

## State Initialization

Create `.retention/state.json` from template with:
- New case ID (RET-YYYY-NNN)
- Current phase: 0
- Empty data structures ready to populate
