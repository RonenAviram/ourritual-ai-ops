---
name: intelligence-gathering
description: Phase 0 — Collect and consolidate all available data about an at-risk therapist from simulated organizational systems.
---

# Intelligence Gathering Skill (Phase 0)

## When Active

Phase 0 of the retention intervention. Activated when a team member first reports an at-risk therapist.

## Objectives

1. Work with whatever the user gives you — even just a name and a gut feeling
2. "Find" the therapist in the system and build their profile
3. Present the intervention process brief (Mermaid flowchart)
4. Simulate pulling data from organizational systems IN THE BACKGROUND
5. Present only a visual summary of key findings
6. Ask targeted clarifying questions to fill gaps
7. Deliver an Intelligence Report as a Word document

## Step-by-Step Flow

### Step 1: Parse Initial Input

The user may provide anything from minimal to detailed input:

**Minimal input (name + feeling):**
> "I have a feeling Cohen isn't really with us anymore. Something has changed."

In this case, Claude "finds" the therapist by name and surfaces the data proactively:
"I pulled up Cohen's profile. I can see why you have that feeling — there are some clear signals in the data."

**Detailed input (name + specifics):**
> "Cohen dropped from 30 sessions per week to 12, I think it's related to a billing issue he had"

In this case, all specifics become ground truth — simulated data must align.

Extract and categorize whatever is provided:

| Category | Look For |
|----------|----------|
| **Name** | The therapist's name — this is the anchor for everything |
| **Volume data** | Session counts, trends, timeframes |
| **Temporal** | When the change started, how fast |
| **Behavioral** | Changes in engagement, responsiveness |
| **Suspected causes** | Anything the user thinks might explain it |
| **Gut feeling** | Vague signals — "something changed", "not really with us" |

Store ALL extracted data points as `user_stated_facts` — these are immutable ground truth.

### Step 2: "Find" the Therapist

Use the name to "pull up" a full profile from Salesforce. Build a realistic identity:

- Use the EXACT name the user provided (expand if needed — "Joe" → "Joe Levy")
- Generate: specialty, tenure, patient load, account health score
- Generate a Salesforce account ID (format: `SF-XXXXX`)
- If the user gave specifics (session counts, etc.) — the profile MUST reflect them exactly

Confirm with the user: "You're talking about [Full Name], [Specialty], been on the platform for [X] years, right?"

### Step 3: Present Brief & Get Approval

Present the Mermaid flowchart from CLAUDE.md Initial Brief Protocol. Wait for explicit approval.

### Step 4: Pull Simulated Data — SILENTLY

**CRITICAL: Do NOT dump raw data into the chat.**

On approval, show a brief processing indicator:

> "Pulling data from Salesforce, Jira, and platform analytics..."

Then do the data generation in the background (use the data-simulation skill). The user should NOT see raw system outputs. Instead, proceed directly to Step 5.

### Step 5: Present Visual Summary

Present ONLY the key findings in a clean, visual format. Highlight what matters:

> **Here's what I found:**
>
> The data confirms your instinct. Three things stand out:
>
> **1. Sharp session decline** — Sessions dropped from [X]/week to [Y]/week over [Z] weeks. That's a [%] decline and it's accelerating.
>
> **2. Unresolved friction** — There are [N] open support tickets, including [most critical one]. The oldest has been open for [days] with no response.
>
> **3. Relationship gap** — Last meaningful contact was [date]. Their last NPS score was [X], with the comment: "[quote]".
>
> **Financial impact:** Revenue went from ₪[peak] to ₪[current] per month. [Name] is in the top [X]% of therapists by revenue.

If the user wants raw data, provide it on request: "Want me to show you the full data from each system?"

### Step 6: Ask Clarifying Questions

Based on gaps, ask 2-3 questions in a structured format:

> Before I assess the risk level, a few things I'd like to understand:
>
> **1.** Do you know if something specific happened recently — a conversation, a complaint, anything that might have triggered this?
>
> **2.** Has anyone on the team been in direct contact with [Name] in the last month?
>
> **3.** How influential is [Name] among other therapists on the platform — do they refer others or have a community presence?

Weave answers into the simulated data seamlessly.

### Step 7: Deliver Intelligence Report

Generate a `.docx` file with the full Intelligence Report. Use python-docx to create a professional document with:
- Header: "OurRitual — Intelligence Report"
- Case ID, date, therapist name
- Profile section
- Key Findings (numbered, with source system cited)
- Data Summary table
- Gaps & Unknowns

Present the file alongside a brief in-chat summary:

> Here's the full Intelligence Report. The headline: [one-sentence summary of the situation].
>
> [Attached: Intelligence_Report_[Name]_RET-YYYY-NNN.docx]
>
> Ready to move to Phase 1: Risk Assessment & Root Cause Analysis?

## Gate Exit Criteria

- [ ] Therapist identified and confirmed with user
- [ ] All simulated systems queried (in background)
- [ ] Visual summary presented
- [ ] Clarifying questions asked and answers integrated
- [ ] Intelligence Report delivered as .docx
- [ ] User approved to proceed
