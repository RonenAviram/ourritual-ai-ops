---
name: followup-loop
description: Phase 4 — Create accountability through follow-up actions, system updates, and outcome tracking.
---

# Follow-Up & Feedback Loop Skill (Phase 4)

## When Active

Phase 4. Conversation debrief complete. Time to close the loop.

## Objectives

1. Generate concrete follow-up action plan
2. Define success metrics and check-in schedule
3. Show simulated system updates
4. Create a case summary for the record
5. Define escalation triggers

## Process

### Step 1: Action Plan Generation

Based on debrief commitments, generate specific action items:

```
Action Item: [Description]
Owner: [Team member / Department]
Deadline: [Specific date]
System: [Where to track — Jira/Salesforce/etc.]
Success indicator: [How to know it's done well]
```

Generate 4-7 action items covering:
- Commitments made to the therapist
- Internal follow-ups (product fixes, billing adjustments, etc.)
- Relationship touchpoints (check-in calls, emails)
- Monitoring tasks (track session volume recovery)

### Step 2: Check-in Schedule

```
📅 Check-in Schedule:
Day 3:   Quick pulse — is anything we promised still pending?
Week 1:  First session volume check — are numbers moving?
Week 2:  Personal check-in call — how are things going?
Month 1: Full review — session trend, satisfaction, engagement
Month 2: Case review — determine if intervention succeeded
Month 3: Close or escalate
```

### Step 3: Simulated System Updates

Show what would be updated in each system:

```
📊 System Updates (simulated):

━━━ Salesforce ━━━
Account SF-[ID] updated:
  • Health Score: [adjusted]
  • Account Notes: "Retention intervention conducted [date]. 
    Risk level [before→after]. Key commitments: [list]."
  • Next Review: [date]
  • Flag: [Active Intervention]

━━━ Jira ━━━
New tickets created:
  • [TICKET-ID]: [Follow-up action] — Assigned: [Owner] — Due: [Date]
  • [TICKET-ID]: [Follow-up action] — Assigned: [Owner] — Due: [Date]
Updated tickets:
  • [TICKET-ID]: Priority raised to [Level], linked to retention case

━━━ Platform ━━━
  • Therapist flagged for monitoring: weekly session trend alerts
  • Account manager notifications enabled
  • Feature usage tracking active
```

### Step 4: Escalation Triggers

Define what would trigger re-intervention:

```
🚨 Escalation Triggers:
• Session volume drops below [X] per week
• No improvement after 2 weeks
• Therapist misses a committed action
• New support tickets filed
• NPS score drops further
• Therapist mentions competitors or intent to leave
```

### Step 5: Case Summary

**Format:**

```
╭──────────────────────────────────────────────────────────────╮
│  📁 Case Summary — [Therapist Name]                           │
│  Case: RET-[YYYY]-[NNN] | Status: Active Monitoring          │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  Timeline                                                    │
│  [Date] — Risk identified (by [team member])                 │
│  [Date] — Intelligence gathered                              │
│  [Date] — Risk assessed: [Score] ([Level])                   │
│  [Date] — Intervention plan prepared                         │
│  [Date] — Retention conversation held                        │
│  [Date] — Debrief completed, risk re-assessed: [Score]       │
│  [Date] — Follow-up plan activated                           │
│                                                              │
│  Key Numbers                                                 │
│  Sessions: [Before] → [At risk] → [Current/Expected]        │
│  Revenue: ₪[Peak] → ₪[Low] → ₪[Expected recovery]          │
│  Risk: [Initial score] → [Current score]                     │
│                                                              │
│  Commitments (tracking)                                      │
│  ☐ [Commitment 1] — Due: [date]                              │
│  ☐ [Commitment 2] — Due: [date]                              │
│  ☐ [Commitment 3] — Due: [date]                              │
│                                                              │
│  Next Check-in: [Date] — [What to look for]                  │
│                                                              │
╰──────────────────────────────────────────────────────────────╯

This case is now in active monitoring. 
I'll be here when you're ready for the first check-in or if anything changes.
```

## Deliverable Format

Generate a `.docx` file with the complete Case Summary. Include: full timeline, action items with owners and deadlines, check-in schedule, system updates, escalation triggers, and key metrics. Present alongside a brief in-chat summary.

> Here's the complete case file. Next checkpoint: [date and what to look for].
>
> [Attached: Case_Summary_[Name]_RET-YYYY-NNN.docx]

## Gate Exit Criteria

- [ ] Action items generated with owners and deadlines
- [ ] Check-in schedule defined
- [ ] System updates shown
- [ ] Escalation triggers defined
- [ ] Full case summary delivered
- [ ] User acknowledges and closes
