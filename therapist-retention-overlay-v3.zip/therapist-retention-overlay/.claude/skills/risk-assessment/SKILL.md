---
name: risk-assessment
description: Phase 1 — Analyze collected intelligence to score churn risk, identify root causes, and estimate intervention urgency.
---

# Risk Assessment & Root Cause Skill (Phase 1)

## When Active

Phase 1. All Phase 0 data is available. User has approved transition.

## Objectives

1. Analyze all intelligence data holistically
2. Score risk level with evidence-based reasoning
3. Identify top 3 root causes ranked by likelihood
4. Estimate churn timeline
5. Surface the single most actionable insight

## Process

### Step 1: Pattern Analysis

Cross-reference data from all simulated systems. Look for:

| Pattern | Sources | Signal |
|---------|---------|--------|
| Volume decline | Analytics | Rate of decline, acceleration, seasonal vs structural |
| Engagement drop | Analytics + Comms | Login frequency, feature usage, response times |
| Unresolved friction | Jira | Open tickets, age, severity, topic clusters |
| Financial pressure | Financial + Salesforce | Revenue shifts, payment delays, contract terms |
| Relationship gaps | Comms | Time since last meaningful contact, NPS trend |
| Platform frustration | Jira + NPS | Feature complaints, usability issues, competitor mentions |

### Step 2: Root Cause Identification

Identify the top 3 probable causes. For each:

```
Root Cause #[N]: [Title]
Likelihood: [High/Medium/Low]
Evidence:
  - [System]: [Specific data point]
  - [System]: [Specific data point]
  - [User input]: [What the team member mentioned]
Mechanism: [How this cause leads to churn]
```

### Step 3: Risk Scoring

Use the risk-scoring-agent for independent assessment.

**Scoring dimensions:**

| Dimension | Weight | What It Measures |
|-----------|--------|-----------------|
| Volume trajectory | 25% | Rate and acceleration of session decline |
| Engagement signals | 20% | Login frequency, feature usage, responsiveness |
| Unresolved friction | 20% | Open issues, their age and severity |
| Financial indicators | 15% | Revenue trend, payment behavior |
| Relationship health | 20% | Recency/quality of contact, NPS, sentiment |

**Risk levels:**

| Level | Score | Implication |
|-------|-------|-------------|
| 🔴 Critical (80-100) | Churn likely within 2 weeks | Immediate intervention required |
| 🟠 High (60-79) | Churn likely within 1-2 months | Urgent intervention needed |
| 🟡 Medium (40-59) | At risk, intervention has good odds | Proactive outreach recommended |

### Step 4: Similar Cases (Simulated)

Generate 1-2 similar past cases for context:

```
Similar Case: [Name], [Specialty], [Date]
Situation: [Brief description]
Intervention: [What was done]
Outcome: [Result]
Lesson: [What applies to current case]
```

### Step 5: Deliver Risk Assessment

**Format:**

```
╭──────────────────────────────────────────────────────────────╮
│  ⚠️ Risk Assessment — [Therapist Name]                        │
│  Case: RET-[YYYY]-[NNN]                                      │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  Risk Score: [XX/100] — [🔴/🟠/🟡] [Level]                   │
│  Estimated churn window: [timeframe]                         │
│                                                              │
│  Root Causes (ranked)                                        │
│  1. [Cause] — [likelihood] — [key evidence]                  │
│  2. [Cause] — [likelihood] — [key evidence]                  │
│  3. [Cause] — [likelihood] — [key evidence]                  │
│                                                              │
│  Key Insight                                                 │
│  [The single most important thing to address — 1-2 lines]    │
│                                                              │
│  Similar Past Case                                           │
│  [Brief case with outcome and lesson]                        │
│                                                              │
╰──────────────────────────────────────────────────────────────╯

Ready to move to Phase 2: Intervention Plan?
```

## Deliverable Format

Generate a `.docx` file with the Risk Assessment. Include: risk score breakdown, root causes with evidence, churn timeline, similar case, and key insight. Present alongside a brief in-chat summary.

> Here's the full risk assessment. Bottom line: [one-sentence key insight].
>
> [Attached: Risk_Assessment_[Name]_RET-YYYY-NNN.docx]
>
> Ready to move to Phase 2: Intervention Plan?

## Gate Exit Criteria

- [ ] Risk score calculated with evidence
- [ ] Top 3 root causes identified and ranked
- [ ] Churn timeline estimated
- [ ] Key insight surfaced
- [ ] User approved to proceed
