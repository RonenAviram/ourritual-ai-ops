---
name: data-simulation
description: Core simulation engine — generates realistic fake data from organizational systems, anchored on user-provided facts.
---

# Data Simulation Skill

## Purpose

This is the engine that makes the overlay feel real. It generates plausible data from organizational systems (Salesforce, Jira, Platform Analytics, etc.) that is always consistent with what the user has told us.

## Always Active

This skill is loaded in every phase. Any time Claude presents data "from a system," these rules apply.

## The Two Laws of Simulation

### Law 1: User Facts Are Sacred
Everything the user says is ground truth. If they say "sessions dropped from 30 to 12" — the simulated analytics MUST show exactly that trajectory. If they say "there was a billing issue" — Jira MUST have a billing-related ticket.

### Law 2: Simulated Data Must Be Plausible
Generated data should feel like it came from a real system. Specific numbers, dates, ticket IDs, names. Not round numbers — not "about 30" but "32" or "28". Not "a few weeks ago" but "June 3rd, 2026".

## Data Generation Rules

### Identifiers
- Salesforce accounts: `SF-XXXXX` (5 digits)
- Jira tickets: `SR-XXXX` (support), `FR-XXXX` (feature request), `BG-XXXX` (bug)
- Case IDs: `RET-YYYY-NNN`
- Use realistic but obviously fake phone extensions and employee IDs

### Numbers
- Session counts: realistic for therapy platform (10-50/week is normal range)
- Revenue: ₪ (shekels), realistic per-session rates (₪200-600)
- Satisfaction: X.X/5 scale
- Health scores: 0-100
- NPS: -100 to 100 scale (individual response: 0-10)
- Never use perfectly round numbers — 32 not 30, 87 not 85, ₪47,200 not ₪50,000

### Dates
- Use actual current dates relative to today
- "3 weeks ago" = calculate the actual date
- Maintain temporal consistency — events that happened "before" must have earlier dates

### Quotes & Comments
- NPS comments: short, realistic, slightly imperfect Hebrew or English
- Support ticket descriptions: specific, referencing actual platform features
- Communication log entries: brief, professional

### Trends
When generating session/revenue trends, create a plausible story:
- Don't make the drop a cliff — show a gradual decline with the user's numbers as anchor points
- Include minor fluctuations (a good week here and there)
- If the user mentioned a trigger event, the decline should correlate with its timing

## System-Specific Templates

### Salesforce Record
```
Account: SF-[ID]
Name: [Full name with title]
Specialty: [Area]
Platform since: [Date]
Contract type: [Standard/Premium/Enterprise]
Account Health Score: [X/100] (was [Y/100] on [date])
Account Owner: [Generated CSM name]
Last review: [Date]
Next review: [Date]
Notes: [1-2 recent entries]
```

### Jira Tickets
```
[ID] | [Priority] | [Subject] | Status: [Open/In Progress/Resolved]
Created: [Date] | Updated: [Date] | Assignee: [Name]
Description: [1-2 lines]
```

Generate 2-5 tickets per therapist. Mix of:
- 1-2 that relate to the user's suspected cause
- 1 that's minor/routine (shows normalcy)
- 0-1 that reveals something the user didn't know about

### Platform Analytics
```
Weekly sessions (last 12 weeks):
[W-12]: XX | [W-11]: XX | [W-10]: XX | ... | [Current]: XX

Cancellation rate: X.X% (platform avg: X.X%)
No-show rate: X.X%
Patient satisfaction: X.X/5 (X reviews)
Login frequency: X times/week (was X times/week)
Features used: [list]
Last feature adopted: [feature] on [date]
```

### Financial
```
Monthly revenue:
[M-6]: ₪XX,XXX | [M-5]: ₪XX,XXX | ... | [Current]: ₪XX,XXX
Payment status: [Current/30 days/60 days]
Outstanding balance: ₪X,XXX or "None"
Revenue rank: Top X% of [total] active therapists
Lifetime value: ₪XXX,XXX
```

## Consistency Tracking

Every generated data point must be mentally tracked throughout the conversation. If in Phase 0 we said "Health Score dropped from 85 to 42" — in Phase 1 when we reference the health score it MUST still be 85→42, not 80→45.

**Rule: Generate once, reference forever.**

## Weaving User Input

When the user provides new information (in clarifying questions or debrief), immediately integrate it:

1. Store as `user_stated_fact`
2. Adjust any simulated data that would conflict
3. Add supporting simulated data that reinforces the new fact
4. Present seamlessly: "That aligns with what I'm seeing in the data — [supporting simulated detail]"

## Anti-Patterns

| ❌ Don't | ✅ Do Instead |
|----------|--------------|
| "The data shows approximately 20 sessions" | "Platform analytics show 22 sessions last week, down from 31 in the same week last month" |
| "There were some support issues" | "Jira shows 3 open tickets — SR-4721 (billing dispute, 18 days old), SR-4698 (scheduling sync error), FR-1205 (group session feature request)" |
| "Revenue has declined" | "Monthly revenue dropped from ₪47,200 in March to ₪18,600 in May — a 60.6% decrease" |
| "They haven't been very engaged" | "Login frequency: 2.1 times/week vs their 6-month average of 5.8 times/week. Last feature interaction: May 28th" |
