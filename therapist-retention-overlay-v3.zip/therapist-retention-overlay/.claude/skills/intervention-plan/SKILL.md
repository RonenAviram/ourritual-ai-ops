---
name: intervention-plan
description: Phase 2 — Build a structured talk-track and action plan for the therapist retention conversation.
---

# Intervention Plan Skill (Phase 2)

## When Active

Phase 2. Risk assessment complete. User ready to prepare for the conversation.

## Objectives

1. Define clear conversation goals
2. Build a structured talk-track with specific language
3. Anticipate objections and prepare responses
4. Define concrete offers within authority
5. Set success criteria for the conversation

## Process

### Step 1: Frame the Conversation

Based on the root causes from Phase 1, determine the conversation framing:

| Root Cause Type | Conversation Frame |
|----------------|-------------------|
| Platform friction | "We value you and want to fix this" — lead with acknowledgment and solutions |
| Financial/value | "Let's make sure you're getting maximum value" — lead with ROI and support |
| Personal/burnout | "We've noticed and we care" — lead with empathy and flexibility |
| Competitive pull | "Here's why we're the right fit" — lead with differentiation and commitment |
| Relationship gap | "We dropped the ball and want to reconnect" — lead with accountability |

### Step 2: Build Talk-Track

Structure the conversation in phases:

**Opening (2-3 minutes)**
- Warm, personal opening — reference something specific about the relationship
- Name the elephant: acknowledge the observed change without being accusatory
- Specific suggested language: "[exact words to use]"

**Discovery (5-7 minutes)**
- Open-ended questions to understand their perspective
- Active listening prompts
- Specific questions tailored to the suspected root causes

**Value Reinforcement (3-5 minutes)**
- Data points about their success on the platform
- Impact metrics they may not be aware of
- Future opportunities relevant to their specialty

**Problem Solving (5-10 minutes)**
- Address each identified root cause with a specific response
- Present concrete offers (see Step 4)
- Collaborate on solutions rather than dictate

**Close & Commit (3-5 minutes)**
- Summarize agreements
- Set specific follow-up dates
- Express genuine commitment to the partnership

### Step 3: Objection Handling

For each anticipated objection, prepare:

```
Objection: "[What they might say]"
What it really means: [The underlying concern]
Response approach: [Strategy]
Suggested language: "[Specific words]"
If they push back further: [Escalation response]
```

Generate 3-5 objections based on root causes.

### Step 4: Define Concrete Offers

What the team member can offer, tiered by escalation:

```
Tier 1 — Within Authority:
• [Offer] — [Why this addresses the root cause]

Tier 2 — Needs Manager Approval:
• [Offer] — [Why this might be needed]

Tier 3 — Last Resort:
• [Offer] — [Only if churn is imminent]
```

**IMPORTANT:** Frame offers as realistic for the OurRitual context — platform support, technical assistance, flexible terms, featured placement, peer community access, etc.

### Step 5: Success Criteria

Define what a successful conversation looks like:

| Outcome | Signal |
|---------|--------|
| ✅ Strong success | Therapist commits to specific actions, expresses renewed engagement |
| ✅ Moderate success | Therapist willing to try solutions, open to follow-up |
| ⚠️ Uncertain | Therapist listened but noncommittal |
| 🔴 Escalation needed | Therapist expressed intent to leave, raised issues beyond current scope |

### Step 6: Deliver Intervention Plan

**Format:**

```
╭──────────────────────────────────────────────────────────────╮
│  📞 Intervention Plan — [Therapist Name]                      │
│  Case: RET-[YYYY]-[NNN]                                      │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  Conversation Goals                                          │
│  1. [Primary goal]                                           │
│  2. [Secondary goal]                                         │
│  3. [Minimum acceptable outcome]                             │
│                                                              │
│  Recommended Frame: [Frame type]                             │
│  "[One-line framing statement]"                              │
│                                                              │
│  ─── Talk-Track ───                                          │
│                                                              │
│  Opening: [Specific language]                                │
│  Key Questions: [3-4 discovery questions]                    │
│  Key Messages: [3-5 points with language]                    │
│  Offers: [Tiered — what you can put on the table]            │
│  Close: [How to wrap and commit]                             │
│                                                              │
│  ─── Objection Handling ───                                  │
│                                                              │
│  "[Objection]" → [Response approach + language]              │
│  "[Objection]" → [Response approach + language]              │
│  "[Objection]" → [Response approach + language]              │
│                                                              │
│  ─── Red Lines ───                                           │
│  • Do NOT promise: [Things to avoid committing to]           │
│                                                              │
│  ─── Success Criteria ───                                    │
│  ✅ Strong: [Description]                                    │
│  ✅ Moderate: [Description]                                  │
│  🔴 Escalation trigger: [Description]                        │
│                                                              │
╰──────────────────────────────────────────────────────────────╯

You're prepped. Go have that conversation.
When you're back, let me know and we'll move to Phase 3: Debrief.
```

## Deliverable Format

Generate a `.docx` file with the Intervention Plan. Include: conversation goals, full talk-track with suggested language, objection handling, tiered offers, red lines, and success criteria. Present alongside a brief in-chat summary.

> Here's your intervention playbook. The core message: [one-sentence framing].
>
> [Attached: Intervention_Plan_[Name]_RET-YYYY-NNN.docx]
>
> You're prepped. When you're back from the conversation, let me know and we'll move to Phase 3.

## Gate Exit Criteria

- [ ] Conversation goals defined
- [ ] Full talk-track with specific language
- [ ] At least 3 objections handled
- [ ] Concrete offers tiered
- [ ] Success criteria clear
- [ ] User confirmed they're ready for the conversation
