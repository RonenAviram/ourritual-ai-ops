---
name: phase-enforcement
description: Gate management — ensures phases proceed in order with human approval at each transition.
---

# Phase Enforcement Skill

## Always Active

This skill is loaded in every phase. Claude MUST check the current phase before any action.

## Phase Gate Rules

### Before Any Work

1. Determine current phase from conversation context
2. Classify the requested work
3. Check if work is allowed in current phase
4. REFUSE work that belongs to a later phase

### Phase Permissions

| Phase | Allowed | NOT Allowed |
|-------|---------|-------------|
| 0 | Data gathering, clarifying questions, intelligence report | Risk scoring, recommendations, talk-tracks |
| 1 | Risk analysis, root cause identification, scoring | Intervention planning, talk-tracks |
| 2 | Talk-track building, objection handling, offer design | Debriefing, follow-up planning |
| 3 | Debrief questions, conversation analysis, risk re-assessment | Action planning, system updates |
| 4 | Follow-up actions, system updates, case summary | N/A (final phase) |

### Violation Response

If the user asks for something from a later phase:

```
⚠️ Phase Gate

Current Phase: [N] — [Name]
Requested: [What they asked for]

This belongs to Phase [X]: [Name].
Let's complete the current phase first.

Remaining in this phase:
• [What still needs to happen]

Would you like to continue with the current phase?
```

### Gate Transition

When all exit criteria for a phase are met:

1. Confirm deliverables are complete
2. Ask for explicit approval: "Ready to move to Phase [N+1]: [Name]?"
3. Accept approval (see CLAUDE.md for approval phrases)
4. Announce the transition: "Moving to Phase [N+1]: [Name]. Here's what we'll do..."

### Always Allowed (Regardless of Phase)

- Asking questions about the process
- Requesting to see current status
- Going back to review a previous phase's output
- Requesting clarification on anything
- Ending the case early

### Override

If the user insists on skipping a phase, acknowledge and comply but note it:

```
Noted — skipping Phase [N]. Be aware that [what we're missing] 
may affect the quality of the intervention plan.

Moving to Phase [X]: [Name].
```
