---
name: conversation-debrief
description: Phase 3 — Process the retention conversation outcomes, extract insights, and re-assess risk.
---

# Conversation Debrief Skill (Phase 3)

## When Active

Phase 3. The team member has had the retention conversation and returned to report.

## Objectives

1. Acknowledge what the user shares — empathy first, process second
2. Collect structured feedback about what happened
3. Parse free-text responses into actionable data
4. Compare actual conversation to plan
5. Re-assess risk based on new information
6. Deliver Debrief Analysis as a Word document

## ⚠️ CRITICAL: Acknowledge Before Asking

When the user returns, they will often lead with emotion: "it was tough", "I think we lost him", "it went great". 

**ALWAYS acknowledge this FIRST.** Reflect back what they said. Show you heard them. THEN proceed to structured questions.

**Example — user says: "It was a tough conversation. I'm not sure if I made it with him."**

BAD response:
> "Welcome back. Let's debrief. Question 1: How did it go?"
(Ignores what they just told you)

GOOD response:
> "That sounds like a difficult conversation. 'Not sure if you made it' — that tells me a lot already. It sounds like Ronen wasn't very receptive. Let me ask a few more questions to understand what happened so we can figure out the best next move."

**The rule: never repeat back to the user what they just said as if you didn't hear it. Build on it.**

## Process

### Step 1: Welcome Back & Acknowledge

When the user returns, acknowledge their emotional state and what they shared. Then transition to questions:

> "[Acknowledge what they said]. Let me ask a few questions to get the full picture — this will help me figure out the best path forward."

### Step 2: Structured Debrief Questions

Ask these questions one at a time. Frame each one with context for why you're asking. If the user already answered something in their opening message, DON'T re-ask it — incorporate it and skip to the next question.

**Question 1: Their Perspective**
*Skip if user already described the overall feel.*
> "When you raised the concern about their reduced activity, what was their reaction? Understanding their initial response tells us a lot about where their head is at."

**Question 2: Reasons Given**
> "Did they give any specific reasons for pulling back? Sometimes what they say — and what they don't say — reveals the real issue."

**Question 3: Surprises**
> "Was there anything they said that surprised you — something we didn't have in our intelligence?"

**Question 4: Agreements**
> "Were any commitments or agreements made — by either side? Even small ones count."

**Question 5: Confidence**
> "Last question — on a scale of 1-10, how confident are you that [Name] will stay active on the platform? Go with your gut."

### Step 3: Process Responses

For each response, Claude must:
1. Extract concrete facts (dates, numbers, commitments)
2. Identify emotional signals (frustration, relief, skepticism, warmth)
3. Flag anything that contradicts earlier intelligence
4. Note new information that wasn't in Phase 0 data

### Step 4: Gap Analysis

Compare the intervention plan (Phase 2) with what actually happened:

| Planned | Actual | Impact |
|---------|--------|--------|
| [Planned message/action] | [What actually happened] | [Positive/Negative/Neutral] |

### Step 5: Risk Re-Assessment

Update the risk score based on conversation outcomes. Show the direction clearly.

### Step 6: Deliver Debrief Analysis

Generate a `.docx` file with the Debrief Analysis. Present alongside a brief in-chat summary with the key takeaway.

Sections:
- Conversation Summary
- Therapist Sentiment (with evidence)
- Commitments Tracker (both sides)
- Risk Re-Assessment (before → after with reasoning)
- New Intelligence
- Red Flags
- Recommended Priority (single most important next action)

> Here's the full debrief analysis. The bottom line: [one-sentence assessment].
>
> [Attached: Debrief_Analysis_[Name]_RET-YYYY-NNN.docx]
>
> Ready to move to Phase 4: Follow-Up & Feedback Loop?

## Gate Exit Criteria

- [ ] User's emotional state acknowledged
- [ ] Debrief questions asked (skipping what was already answered)
- [ ] Commitments tracked (both sides)
- [ ] Risk score re-assessed
- [ ] New intelligence captured
- [ ] Debrief Analysis delivered as .docx
- [ ] User approved to proceed
